// Structured content for Web Grouth. Kept separate from markup so new
// sections (marketplace inventory, pricing, categories) can be added later
// by extending these arrays rather than rebuilding pages.

export const nav = [
  { label: 'Home', href: '/' },
  { label: 'Guest Posting', href: '/guest-posting' },
  { label: 'SEO Services', href: '/seo-services' },
  { label: 'Blog', href: '/blog' },
  { label: 'About', href: '/about' },
];

export const services = [
  {
    icon: 'link',
    title: 'Guest Posting',
    text: 'Place your brand in relevant, editorially-run publications with a contextual backlink that actually fits the story.',
    href: '/guest-posting',
  },
  {
    icon: 'search',
    title: 'SEO Services',
    text: 'Technical clarity, useful content, and authority building that compounds — not a one-off ranking stunt.',
    href: '/seo-services',
  },
  {
    icon: 'megaphone',
    title: 'Digital PR & Outreach',
    text: 'Turn a strong idea into coverage, mentions, and relationships with publishers who cover your space.',
    href: '/contact',
  },
] as const;

export const capabilities = [
  'Guest Posting',
  'Guest Post Marketplace',
  'Link Building',
  'Link Insertion',
  'Blogger Outreach',
  'Content Marketing',
  'Digital PR',
  'SEO Content',
];

export const whyUs = [
  {
    title: 'Relevant publishers',
    text: 'Choose context over volume, with opportunities aligned to your niche and audience.',
  },
  {
    title: 'Transparent process',
    text: 'Know exactly what you are ordering, why it fits, and what happens after you say yes.',
  },
  {
    title: 'Content that earns its place',
    text: 'Useful, clear writing written for the reader first — and search second.',
  },
  {
    title: 'No guaranteed-ranking claims',
    text: 'We build credible inputs, not promises no honest agency can make.',
  },
];

export const process = [
  {
    step: '01',
    title: 'Choose a direction',
    text: 'Tell us your niche, target audience, and the goal behind the request.',
  },
  {
    step: '02',
    title: 'Match the opportunity',
    text: 'We surface a relevant publisher or outreach route for your category.',
  },
  {
    step: '03',
    title: 'Shape the story',
    text: 'Approve the brief, the draft, and the publication details before anything goes live.',
  },
  {
    step: '04',
    title: 'Grow from there',
    text: 'Track what published and build the next relevant signal on top of it.',
  },
];

export const faqs = [
  {
    q: 'What is guest posting?',
    a: 'Guest posting is publishing a useful, original article on another relevant website. Done well, it introduces your brand to a new audience and earns a contextual mention back to your site.',
  },
  {
    q: 'Can I provide my own article?',
    a: 'Yes. You can send your own draft or ask about content support. We align the brief with the publication\u2019s editorial guidelines before anything goes live.',
  },
  {
    q: 'How long does publication take?',
    a: 'Timing depends on the publication and its editorial queue. We share the expected window before an order is confirmed.',
  },
  {
    q: 'What niches and websites are available?',
    a: 'Our inventory is expanding. Contact us with your category and target market and we\u2019ll point you to relevant opportunities that fit.',
  },
];

// Placeholder category structure for the upcoming Guest Post Marketplace.
// These are illustrative *categories*, not real inventory, metrics, or
// client data — clearly labelled as a preview until real listings are added.
export const marketplaceCategories = [
  { icon: 'trending', label: 'Business & Finance' },
  { icon: 'heart', label: 'Health & Wellness' },
  { icon: 'cpu', label: 'SaaS & Technology' },
  { icon: 'compass', label: 'Lifestyle & Travel' },
  { icon: 'shopping', label: 'E-commerce & Retail' },
  { icon: 'graduation', label: 'Education' },
] as const;

export const blogPosts = [
  {
    slug: 'guest-posting-that-earns-its-place',
    category: 'Guest Posting',
    title: 'Guest posting that earns its place',
    date: 'August 12, 2026',
    read: '6 min read',
    excerpt: 'A practical framework for choosing topics, publications, and links that feel useful \u2014 not forced.',
    intro: 'The best guest posts do not feel like a transaction. They feel like a useful answer in the right room.',
  },
  {
    slug: 'what-makes-a-backlink-useful',
    category: 'Link Building',
    title: 'What makes a backlink useful?',
    date: 'July 28, 2026',
    read: '5 min read',
    excerpt: 'Authority matters, but context, audience, and intent decide whether a link contributes anything meaningful.',
    intro: 'Authority matters, but context, audience, and intent decide whether a link contributes anything meaningful.',
  },
  {
    slug: 'the-seo-brief-your-content-team-needs',
    category: 'SEO',
    title: 'The SEO brief your content team needs',
    date: 'July 10, 2026',
    read: '7 min read',
    excerpt: 'Move beyond keywords with a brief that gives writers a real audience, angle, and reason to care.',
    intro: 'Move beyond keywords with a brief that gives writers a real audience, angle, and reason to care.',
  },
] as const;
