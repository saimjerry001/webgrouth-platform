// Central business configuration for Web Grouth.
// Update contact details here — every page and component reads from this file,
// so a single edit here propagates across the whole site.

export const business = {
  name: 'Web Grouth',
  tagline: 'Guest Posting, SEO & Link Building',
  url: 'https://webgrouth.com',
  whatsapp: {
    display: '+92 332 7810261',
    number: '923327810261',
    link: 'https://wa.me/923327810261',
  },
  // PLACEHOLDER — no official business email has been confirmed yet.
  // Replace this value the moment a real address is available; every
  // mailto/display usage across the site pulls from this single constant.
  email: {
    address: 'contact@webgrouth.com',
    isPlaceholder: true,
  },
  social: {
    // Add confirmed profiles here later (e.g. linkedin, twitter/x, facebook).
  },
} as const;

export function whatsappLink(message: string) {
  return `${business.whatsapp.link}?text=${encodeURIComponent(message)}`;
}
